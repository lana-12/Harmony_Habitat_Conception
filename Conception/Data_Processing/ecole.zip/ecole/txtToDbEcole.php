<?php
run();

/**
 * Script qui lit le fichier text des écoles et fait les requêtes d'insertion dans la table 'ecole'
 * a besoin de la table 'ecole_categorie' pour fonctionner pour gérer la catégorie des écoles
 */
function run() {
    $host = 'localhost';
    $dbName = 'harmony_habitat';
    $userName = 'user_harmony_habitat';
    $userPassword = 'harmony_habitat';
    $db = new PDO("mysql:host=$host;dbname=$dbName", $userName, $userPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $fileToRead = fopen('./txt/school2.txt', 'r');
    $isSomeError = false;
    $countOk = 0;
    $countKo = 0;
    $errorDatas = [];
    // première ligne du fichier des erreurs
    $errorDatas[] =  'comment;code_commune;categorie;nom_ecole;nom_commune_ecole;numero_uai_ecole;rue_adresse_ecole;code_postal_adresse_ecole;ville_adresse_ecole;latitude;longitude';
    while (($line = fgetcsv($fileToRead, 1000, ';')) !== FALSE) {
        $nom_ecole = $line[3];
        $nom_commune_ecole = $line[1];
        $numero_uai_ecole = $line[9];
        $rue_adresse_ecole = $line[4];
        $code_postal_adresse_ecole = $line[5];
        $ville_adresse_ecole = $line[6];

        $categorie = $line[2];
        $latitude = $line[7];
        $longitude = $line[8];
        $code_commune = $line[0];
        // si code_commune a 4 caractere : ajouter un '0'
        if (strlen($code_commune) <= 4) {
            $code_commune = str_pad($code_commune, 5, "0", STR_PAD_LEFT);
        }

        // recuperation de l'id de la catégorie :
        $categorieQuery = $db->prepare('SELECT c.id FROM harmony_habitat.ecole_categorie c WHERE c.categorie = ?');
        $categorieQuery->bindValue(1, $categorie, PDO::PARAM_STR);
        $categorieQuery->execute();
        $categorieRow = $categorieQuery->fetch(PDO::FETCH_ASSOC);

        // récupération de l'id de la commune à partir de son code commune
        $communeQuery = $db->prepare('SELECT c.id FROM harmony_habitat.commune c WHERE c.code_commune = ?');
        $communeQuery->bindValue(1, $code_commune, PDO::PARAM_STR);
        $communeQuery->execute();
        $communeRow = $communeQuery->fetch(PDO::FETCH_ASSOC);

        $isPositionOk = (strlen($latitude) > 0) && (strlen($longitude) > 0);

        if($categorieRow && $communeRow) {
            $countOk++;
            $id_categorie = $categorieRow['id'];
            $id_commune = $communeRow['id'];
            
            if($isPositionOk) {
               // insert de la position et récupération de l'id de la nouvelle position
                $stmtPosition = $db->prepare('INSERT INTO position_gps (latitude, longitude) VALUES (?, ?)');
                $stmtPosition->bindParam(1, $latitude);
                $stmtPosition->bindParam(2, $longitude);
                $stmtPosition->execute();
                // important !!
                $id_position = $db->lastInsertId(); 
            }
            else {
                $id_position = null;
            }
            

            $stmtEcole = $db->prepare('INSERT INTO ecole (nom_ecole, nom_commune_ecole, numero_uai_ecole, rue_adresse_ecole, code_postal_adresse_ecole, ville_adresse_ecole, id_categorie, id_position, id_commune) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmtEcole->bindParam(1, $nom_ecole);
            $stmtEcole->bindParam(2, $nom_commune_ecole);
            $stmtEcole->bindParam(3, $numero_uai_ecole);
            $stmtEcole->bindParam(4, $rue_adresse_ecole);
            $stmtEcole->bindParam(5, $code_postal_adresse_ecole);
            $stmtEcole->bindParam(6, $ville_adresse_ecole);
            $stmtEcole->bindParam(7, $id_categorie);
            $stmtEcole->bindParam(8, $id_position);
            $stmtEcole->bindParam(9, $id_commune);

            $stmtEcole->execute();
            echo 'insertion ok n° : ' . $countOk . PHP_EOL;
        }
        else {
            $countKo++;
            $isSomeError = true;
            echo 'Erreur n° : ' . $countKo .' de sous-requêtes / ' . PHP_EOL;
            $comment = '';
            if(!$isPositionOk) {
                echo 'position ko / ' . PHP_EOL;
                $comment .= 'position ko !';
            };
            if(!$communeRow) {
                echo 'commune ko / ' . PHP_EOL;
                $comment .= 'commune ko !';
            };
            if(!$categorieRow) {
                echo 'categorie ko / ' . PHP_EOL;
                $comment .= ' / categorie ko !';
            }
            $errorDatas[] = $comment . ";" 
            . $code_commune . ";" 
            . $categorie . ";" 
            . $nom_ecole . ";" 
            . $nom_commune_ecole . ";" 
            . $numero_uai_ecole . ";" 
            . $rue_adresse_ecole . ";" 
            . $code_postal_adresse_ecole . ";"
            . $ville_adresse_ecole . ";" 
            . $latitude . ";"
            . $longitude
            ;
        }

    }
    if($isSomeError) {
        
        // ecrire dans un fichier
        $outputFile = "txt/errors_data_ecole.txt";
        $outputFileStream = fopen($outputFile, 'w');
        foreach($errorDatas as $d) {
            fwrite($outputFileStream, $d . "\n");
        }
        fclose($outputFileStream);
    }
    fclose($fileToRead);
    echo 'Peuplement de la table \'ecole\' terminé.' . $countOk . ' écoles insérées. Erreurs : ' . $countKo . PHP_EOL;
}
?>