<?php

function dump($var)
{
    echo '<pre>';
    var_dump($var);
    echo '</pre>';
}

/* script pour récupérer => 
    - code_commune_ecole =>[25]
    - nom_commune_ecole =>[10]
    - type_ecole => [19]
    - nom_ecole => [3]
    - adresse_ecole => [5]
    - code_postal_ecole =>[8]
    - ville_ecole =>[9]
    - latitude_ecole => [14]
    - longitude_ecole => [15]
    - numero_uai => [0]

    Envoyé sur fichier school2.txt
*/

run();

function run()
{
    $file = fopen('./school.csv', 'r');
    $count = 0;
    $data = [];

    while ($line = fgetcsv($file, null, ";")) {
        //Enlever la première ligne des intitulés col
        if ($count > 0) {

            //Gestion nomEcole vide
            if($line[3] === ""){
                $line[3] = $line[19]. ' de '. $line[9];
            }
            //Correspons à l'ordre ds ma table test ecole de ma BDD ecole
            $objectSchool = [
                "code_commune_ecole" =>$line[25],
                "nom_commune_ecole" =>$line[10],
                "type_ecole" => $line[19],
                "nom_ecole" => $line[3],
                "adresse_ecole" => $line[5],
                "code_postal_ecole" =>$line[8],
                "ville_ecole" =>$line[9],
                "latitude_ecole" => $line[14],
                "longitude_ecole" => $line[15],
                "numero_uai" => $line[0],
            ];

            $data[] = $objectSchool;

        }
        $count++;
    }
    fclose($file);

    $file = fopen('./txt/school2.txt', 'w');
    foreach ($data as $school) {
        // dump($school);
        $line = implode(';', $school);
        fwrite($file, $line . PHP_EOL);
    }
    fclose($file);
}
