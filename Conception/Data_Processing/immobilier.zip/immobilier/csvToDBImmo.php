<?php 
/**
 * Script qui lit le fichier csv des données immo, verifie les clés étrangères et fait les insertions dans la tables 'prix_immo'
 * Collecte les données non valides dans un fichier text
 */
try {
    $host = 'localhost';
    $dbName = 'harmony_habitat';
    $userName = 'user_harmony_habitat';
    $userPassword = 'harmony_habitat';
    $db = new PDO("mysql:host=$host;dbname=$dbName", $userName, $userPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $csvFile = './csv/pred-mai-mef-dhup.csv';
    $type_immo = 'Maison';
    $isSomeError = false;
    // $type_immo = 'Appartement'; --> done !
    // $type_immo = 'Appartement T3'; --> done !
    // $type_immo = 'Appartement T1 T2'; --> done !
    // $type_immo = 'Maison'; --> ec

    $file = fopen($csvFile, 'r');
    $errorDatas = [];
    $countOk = 0;
    $countKo = 0;
    $count = 0;
    echo "Lecture et analyse du fichier csv." . PHP_EOL;
    fgetcsv($file, 1000, ';'); // saute 1e ligne
    while (($line = fgetcsv($file, 1000, ';')) !== FALSE) {
        
        $code_commune = $line[1];
        $prix_m2 = $line[6];

        // reduire le prix à decimal(6,2)
        $prix_m2 = number_format(floatval($prix_m2), 2, '.', '');

        // récupération de l'id de la commune à partir de son code commune
        $communeQuery = $db->prepare('SELECT c.id_commune FROM harmony_habitat.commune c WHERE c.code_commune = ?');
        $communeQuery->bindValue(1, $code_commune, PDO::PARAM_STR);
        $communeQuery->execute();
        $communeRow = $communeQuery->fetch(PDO::FETCH_ASSOC);

        // récupération de l'id du type à partir du nom du type
        $typeImmoQuery = $db->prepare('SELECT t.id FROM harmony_habitat.type_immo t WHERE t.type = ?');
        $typeImmoQuery->bindValue(1, $type_immo, PDO::PARAM_STR);
        $typeImmoQuery->execute();
        $typeImmoRow = $typeImmoQuery->fetch(PDO::FETCH_ASSOC);

        
        if($communeRow && $typeImmoRow) {
            $countOk++;
            $id_commune = $communeRow['id_commune'];
            $id_type = $typeImmoRow['id'];

            $sql = 'INSERT INTO prix_immo (prix_m2, id_type, id_commune) VALUES (?, ?, ?)';
            $stmtCrime = $db->prepare($sql);
            $stmtCrime->bindValue(1, $prix_m2, PDO::PARAM_STR);
            $stmtCrime->bindValue(2, $id_type, PDO::PARAM_INT);
            $stmtCrime->bindValue(3, $id_commune, PDO::PARAM_INT);
            $stmtCrime->execute();
        }
        else {
            $isSomeError = true;
            $countKo++;
            // ecrire dans un fichier les datas non reconnues : code_commune
            echo 'Erreur des sous-requêtes / ' . PHP_EOL;
            if(!$communeRow) echo 'commune ko / ' . PHP_EOL;
            if(!$typeImmoRow) echo 'type immo ko / ' . PHP_EOL;
            $errorDatas[] = $code_commune . ";" . $prix_m2;
        }

        if($isSomeError) {
            // ecrire dans un fichier
            $outputFile = "text/errors_data_immo.txt";
            $outputFileStream = fopen($outputFile, 'w');
            foreach($errorDatas as $d) {
                fwrite($outputFileStream, $d . "\n");
            }
            fclose($outputFileStream);
        }

    }
    //fclose($fileStream);
    echo 'Peuplement de la table \'prix_immo\' pour le type : ' . $type_immo . ' terminé.' . $countOk . ' communes insérées. Erreurs : ' . $countKo . PHP_EOL;

} catch (PDOException $e) {
    echo 'Erreur : ' . $e->getMessage() . PHP_EOL;
}

// parcourir csv

    // extraire code_commune / prix_loyer_m2
    // fixer type_immo selon le fichier csv
        // fixer id du type_immo
    // recuperer l'id de la commune
?>