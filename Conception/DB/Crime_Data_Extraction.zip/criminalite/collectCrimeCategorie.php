<?php
/**
 * Script qui collecte les catégories de crimes à partir 
 * des fichiers text 'data_XXXX.txt' contenant les datas 
 * par année (un fichier par année) et les écrit dans un 
 * fichier text : 'categories_sans_doublons.txt'
 */
$directory = './text/';

$categories = [];

$fileCount = 0;
foreach (glob($directory . 'data_*.txt') as $file) {
    $fileCount++;
    echo 'Fichier n° : ' . $fileCount . PHP_EOL;
    echo '************************************' . PHP_EOL;
    $lineCount = 0;

    if (($fileStream = fopen($file, 'r')) !== FALSE) {
        while (($line = fgets($fileStream)) !== FALSE) {
            $lineCount++;
            echo 'Ligne n° : ' . $lineCount . PHP_EOL;
            $data = explode(';', $line);
            $categorie = trim($data[2]);

            if (!in_array($categorie, $categories)) {
                $categories[] = $categorie;
            }
        }

        fclose($fileStream);
    }
    echo 'fin traitement fichier n° : ' . $fileCount . PHP_EOL;
}

sort($categories);

$outputFile = 'categories_sans_doublons.txt';

if (($outputStream = fopen('text/' . $outputFile, 'w')) !== FALSE) {
    foreach ($categories as $categorie) {
        fwrite($outputStream, "$categorie\n");
    }

    fclose($outputStream);
    echo 'Collecte des classes terminée.';
} else {
    echo 'Erreur ouverture du fichier de sortie.';
}
?>
