<?php
/**
 * Script qui utilise le fichier 'communes-departement-region.csv' (venant de :'https://www.data.gouv.fr/fr/datasets/communes-de-france-base-des-codes-postaux/')
 * comme source et qui extrait, ligne par ligne, les infos nécessaires à la bdd, puis les écrit dans le fichier text 'communes.txt'.
 * Utilise un tableau intermédiaire contenant les données collectées et qui sert dans la phase d'écriture du fichier text.
 */
run();

function run()
{
    $file = fopen('./csv/communes-departement-region.csv', 'r');
    $data = [];
    $count = 0;
    echo "Lecture et analyse du fichier csv." . PHP_EOL;
    while (($line = fgetcsv($file)) !== FALSE) {
        if ($count > 0) {
            $objectToAdd = [
                "code_commune" => $line[0],
                "code_region" => $line[13],
                "code_departement" => $line[11],
                "nom" => $line[10],
                "code_postal" => $line[2],
                "latitude" => $line[5],
                "longitude" => $line[6]
            ];
            if (count($data) === 0) {
                $data[] = $objectToAdd;
            } else {
                if (isNewCodeCommune($objectToAdd["code_commune"], $data)) {
                    $data[] = $objectToAdd;
                }
            }
        }
        $count++;
    }
    fclose($file);
    echo "Fichier csv analysé." . PHP_EOL;
    $file = fopen('./text/communes.txt', 'w');
    foreach ($data as $d) {
        $line = implode(';', $d);
        fwrite($file, $line . PHP_EOL);
    }
    fclose($file);
    echo "Ecriture fichier text terminée." . PHP_EOL;
}


/**
 * Fonction qui renvoi vrai si $newCodeCommune n'est pas déjà
 * présent dans le tableau $tabDatas.
 */
function isNewCodeCommune($newCodeCommune, $tabDatas)
{
    foreach ($tabDatas as $data) {
        if ($data['code_commune'] === $newCodeCommune) {
            return false;
        }
    }
    return true;
}
