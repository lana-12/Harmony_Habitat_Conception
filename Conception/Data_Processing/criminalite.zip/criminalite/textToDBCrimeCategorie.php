<?php
/**
 * Script qui peuple la table crime_categorie à partir du fichier text de la collecte : 'categories_sans_doublons.txt'.
 */
try {
    $host = 'localhost';
    $dbName = 'harmony_habitat';
    $userName = 'user_harmony_habitat';
    $userPassword = 'harmony_habitat';

    $db = new PDO("mysql:host=$host;dbname=$dbName", $userName, $userPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $textFile = 'categories_sans_doublons.txt';

    if (($fileStream = fopen('text/' . $textFile, 'r')) !== FALSE) {
        while (($line = fgets($fileStream)) !== FALSE) {
            $categorie = trim($line);

            $stmt = $db->prepare('INSERT INTO crime_categorie (categorie) VALUES (?)');
            $stmt->bindParam(1, $categorie);
            $stmt->execute();
        }

        fclose($fileStream);
        echo 'Peuplement de la table "crime_categorie" terminé.' . PHP_EOL;
    } else {
        echo 'Erreur ouverture du fichier texte.';
    }
} catch (PDOException $e) {
    echo 'Erreur : ' . $e->getMessage();
}
?>
