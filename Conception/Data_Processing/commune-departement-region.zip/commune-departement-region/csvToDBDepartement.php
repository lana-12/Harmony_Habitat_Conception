<?php

// script qui lit le csv des départements et peuple la table departement
try {
    $host = 'localhost';
    $dbName = 'harmony_habitat';
    $userName = 'user_harmony_habitat';
    $userPassword = 'harmony_habitat';
    $db = new PDO("mysql:host=$host;dbname=$dbName", $userName, $userPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $csvFile = 'csv/departements-france.csv';

    if (($fileStream = fopen($csvFile, 'r')) !== FALSE) {
        // Ignorer la première ligne (en-têtes)
        fgetcsv($fileStream, 1000, ',');

        while (($data = fgetcsv($fileStream, 1000, ',')) !== FALSE) {
            $code_departement = $data[0];
            $nom_departement = $data[1];
            $code_region = $data[2];

            // gestion de la clé étrangère de la région
            $regionQuery = $db->prepare('SELECT id_region FROM region WHERE code_region = ?');
            $regionQuery->bindParam(1, $code_region);
            $regionQuery->execute();
            $row = $regionQuery->fetch(PDO::FETCH_ASSOC);

            if ($row) {
                $id_region = $row['id_region'];
                $stmt = $db->prepare('INSERT INTO departement (code_departement, nom_departement, id_region) VALUES (?, ?, ?)');
                $stmt->bindParam(1, $code_departement);
                $stmt->bindParam(2, $nom_departement);
                $stmt->bindParam(3, $id_region);

                $stmt->execute();
            }
        }

        fclose($fileStream);
        echo 'Insertion des données terminée.';
    } else {
        echo 'Erreur ouverture fichier CSV.' . PHP_EOL;
    }
} catch (PDOException $e) {
    echo 'Erreur : ' . $e->getMessage();
}
?>
