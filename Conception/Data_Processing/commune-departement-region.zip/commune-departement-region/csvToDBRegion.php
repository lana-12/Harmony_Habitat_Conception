<?php
// script qui lit le csv des régions et peuple la table region
try {
    $host = 'localhost';
    $dbName = 'harmony_habitat';
    $userName = 'user_harmony_habitat';
    $userPassword = 'harmony_habitat';
    $db = new PDO("mysql:host=$host;dbname=$dbName", $userName, $userPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $csvFile = 'csv/regions-france.csv';

    if (($fileStream = fopen($csvFile, 'r')) !== FALSE) {
        // saute la 1ere ligne : ne pas utiliser
        fgetcsv($fileStream, 1000, ',');
        while (($data = fgetcsv($fileStream, 1000, ',')) !== FALSE) {
            $code_region = $data[0];
            $nom_region = $data[1];

            $stmt = $db->prepare('INSERT INTO region (code_region, nom_region) VALUES (?, ?)');
            $stmt->bindParam(1, $code_region);
            $stmt->bindParam(2, $nom_region);

            $stmt->execute();
        }

        fclose($fileStream);
        echo 'Insertion des données terminée.' . PHP_EOL;
    } else {
        echo 'Erreur ouverture fichier CSV.' . PHP_EOL;
    }
} catch (PDOException $e) {
    echo 'Erreur : ' . $e->getMessage() . PHP_EOL;
}
?>
