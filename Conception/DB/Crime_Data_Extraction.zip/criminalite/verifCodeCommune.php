<?php
/**
 * Script qui, à partir des données de 
 * 'codes_commune_sans_doublons.txt', vérifie dans la 
 * table 'commune' que les codes existent ou pas.
 * Ecrit, apres la lecture de la source, les codes commune
 * non reconnus dans le fichier 
 * 'codes_commune_inexistants.txt'
 */
try {
    $host = 'localhost';
    $dbName = 'harmony_habitat';
    $userName = 'user_harmony_habitat';
    $userPassword = 'harmony_habitat';

    $db = new PDO("mysql:host=$host;dbname=$dbName", $userName, $userPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $codesCommuneFile = 'codes_commune_sans_doublons.txt';

    $outputFile = 'codes_commune_inexistants.txt';
    $count = 0;

    if (($inputStream = fopen('text/' . $codesCommuneFile, 'r')) !== FALSE) {
        $nonExistentCodes = [];

        while (($codeCommune = fgets($inputStream)) !== FALSE) {
            $codeCommune = trim($codeCommune);
            $count++;
            echo 'ligne n° : ' . $count . PHP_EOL;
            //$codeCommune = ltrim($codeCommune, '0');

            $stmt = $db->prepare('SELECT id_commune FROM commune WHERE code_commune = ?');
            $stmt->bindParam(1, $codeCommune);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$row) {
                $nonExistentCodes[] = $codeCommune;
            }
        }

        fclose($inputStream);
 
        if (($outputStream = fopen('text/' . $outputFile, 'w')) !== FALSE) {
            foreach ($nonExistentCodes as $code) {
                fwrite($outputStream, "$code\n");
            }

            fclose($outputStream);
            echo 'Vérification terminée. Les codes de commune inexistants ont été écrits dans le fichier "codes_commune_inexistants.txt"' . PHP_EOL;
        } else {
            echo 'Erreur ouverture du fichier de sortie' . PHP_EOL;
        }
    } else {
        echo 'Erreur ouverture du fichier de codes de commune' . PHP_EOL;
    }
} catch (PDOException $e) {
    echo 'Erreur : ' . $e->getMessage() . PHP_EOL;
}
?>
