<?php
run();

/**
 * Script qui lit le fichier text et fait les insertions dans la table 'ecole_categorie'
 */
function run() {
    $host = 'localhost';
    $dbName = 'harmony_habitat';
    $userName = 'user_harmony_habitat';
    $userPassword = 'harmony_habitat';
    $db = new PDO("mysql:host=$host;dbname=$dbName", $userName, $userPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $tableName = 'ecole_categorie';
    $fileToRead = fopen('./txt/type_ecole.txt', 'r');

    while ($categorie = fgets($fileToRead)) {
        $categorie = str_replace(array("\r", "\n"), '', $categorie);
        $stmt = $db->prepare('INSERT INTO ecole_categorie (categorie) VALUES (?)');
        $stmt->bindParam(1, $categorie);
        $stmt->execute();
    }

    fclose($fileToRead);
}
?>