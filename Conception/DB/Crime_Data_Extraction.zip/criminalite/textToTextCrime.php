<?php

/**
 * Script qui lit le fichier des stats de crime pour une année, 
 * calcule et formate les données numériques avec exposant
 * puis enregistre le résultat dans un fichier text.
 */

$year = '2016';
$sourceFile = "text/data_$year.txt";
$outputFile = "result/data_ok_$year.txt";
$outputFileStream = null;

// Codes communaux à exclure
$excludedCodes = ['13055', '48166', '69123', '75056', '76601'];

if (($fileStream = fopen($sourceFile, 'r')) !== FALSE) {
    //$dataByYear = '';
    $count = 0;
    // pas de saut de la 1ere ligne sinon :
    // fgetcsv($fileStream, 1000, ';');

    while (($data = fgetcsv($fileStream, 1000, ';')) !== FALSE) {
        $code_commune = $data[0];
        if (!in_array($code_commune, $excludedCodes)) {
            $count++;
            echo 'ligne n° : ' . $count . PHP_EOL;
            $annee = $data[1];
            $categorie = $data[2];

            // arrondir la valeur pour en faire un entier
            $crimeCount = $data[3];
            $crimeCount = str_replace(',', '.', $crimeCount);
            $crimeCount = (float) $crimeCount;
            $crimeCount = customRound($crimeCount);
            
            // traiter les exposant et arrondir pour formater : xxxx.xxxxxx
            $crimeRatio =  $data[4];
            if($crimeRatio !== '0') {
                // détecter le cas '0,00000000000000e+00'
                $crimeRatio = str_replace(',', '.', $crimeRatio);

                if($crimeRatio === '0.00000000000000e+00') {
                    $crimeRatio = 0;
                }
                else {
                    $crimeRatio = (float) $crimeRatio;
                    //$crimeRatio = sprintf("%.6f", $crimeRatio); 
                    $crimeRatio = number_format($crimeRatio, 6, '.', '');
                }
            }

            if ($outputFileStream === null) {
                $outputFileStream = fopen($outputFile, 'w');
            }

            fwrite($outputFileStream, "$code_commune;$annee;$categorie;$crimeCount;$crimeRatio\n");
        }
    }
    fclose($outputFileStream);
    fclose($fileStream);
    echo 'Traitement des données terminé' . PHP_EOL;
} else {
    echo 'Erreur ouverture du fichier source' . PHP_EOL;
}

/*
function format_number($num, $floatsep = ",", $thouthandsep="."){ 
    $float = null; 
    if((int)$num != (float)$num ) $float = 2; 
    return number_format($num,$float,$floatsep,$thouthandsep); 
}*/

function customRound($value) {
    $integerPart = floor($value);
    $decimalPart = $value - $integerPart;

    if ($decimalPart >= 0.5) {
        return ceil($value);
    } else {
        return floor($value);
    }
}
