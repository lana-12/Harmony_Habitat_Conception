<?php

function dump($var)
{
    echo '<pre>';
    var_dump($var);
    echo '</pre>';
}

/**
 * Script récupérer les types d'école dans le fichier school2.txt
 * Transfert sur type_ecole.txt
 * 30 de lignes
 */

run();

function run()
{
    $file = './txt/school2.txt';
    $typesSchool = [];

    if (($fileStream = fopen($file, 'r')) !== FALSE) {

        while (($line = fgets($fileStream)) !== FALSE) {
            // dump($line);

            $data = explode(';', $line);
            // dump($data[2]);

            if (!in_array($data[2], $typesSchool)) {
                $typesSchool[] = $data[2];
            }
        }
        fclose($fileStream);
        // Array
        // dump($typesSchool);


    } else {
        echo 'file pas ouvert';
    }

    $file = fopen('./txt/type_ecole.txt', 'w');

    foreach ($typesSchool as $type) {
        fwrite($file, $type . PHP_EOL);
    }
    fclose($file);

}

