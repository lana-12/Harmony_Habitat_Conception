<?php
/**
 * Script qui lit le fichier csv et réparti les datas dans des fichiers texte (un par année).
 */
$csvFile = 'csv/crimes_communes_2022_big.csv';

if (($fileStream = fopen($csvFile, 'r')) !== FALSE) {
    $dataByYear = [];
    $count = 0;
    fgetcsv($fileStream, 1000, ';');
    while (($data = fgetcsv($fileStream, 1000, ';')) !== FALSE) {
        $count++;
        echo 'ligne n° : ' . $count . PHP_EOL;        
        $code_insee = $data[0];
        $date = $data[1];
        $classe = $data[2];

        $dataType = $data[4];
        $crimeCount = 0;
        $crimeRatio = 0;
        if($dataType === 'diff') {
            $crimeCount = $data[5];
            $crimeRatio = $data[6];
        }
        else if($dataType === 'ndiff') {
            $crimeCount = $data[7];
            $crimeRatio = 0;
        }
        //$year = date('Y', strtotime($date));
        $year = '20' . $date;
        if (!isset($dataByYear[$year])) {
            $dataByYear[$year] = fopen("text/data_$year.txt", 'w');
        }

        fwrite($dataByYear[$year], "$code_insee;$year;$classe;$crimeCount;$crimeRatio\n");
    }
    foreach ($dataByYear as $year => $file) {
        fclose($file);
    }
    fclose($fileStream);
    echo 'Tri des données terminé.';
} 
else {
    echo 'Erreur ouverture du fichier CSV.';
}
?>
