# Données de la criminalité


## Source

- fichier : 'donnee-data.gouv-2022-geographie2023-produit-le2023-07-17.csv' 
- lien : 'https://www.data.gouv.fr/fr/datasets/bases-statistiques-communale-et-departementale-de-la-delinquance-enregistree-par-la-police-et-la-gendarmerie-nationales/#/resources'


## Process

- tri des données en plusieurs fichiers text (un par année) ex. : 'data_2019.txt' pour 2019 / script : 'csvToTextByYear.php'
- collecte des catégories depuis les fichiers text ('data_XXXX.txt') / script : 'collectCrimeCategorie.php'
- collecte des codes communes depuis les fichiers text ('data_XXXX.txt') / script : 'collectCodeCommune.php'
- creation, à partir des code communes collectés, de la liste des codes communes non présents dans la table 'commune' et écriture du résultat dans un fichier text / script : 'verifCodeCommune.php'
- formatage des données à partir des fichiers text ('data_XXXX.txt') et écriture des résultats dans plusieurs fichiers text (un par année, 'data_ok_XXX.txt') en excluant les communes dont le code commune n'existe pas dans la table 'commune' / script : 'textToTextCrime.php'
- création de la table 'crime_categorie'
- insertion des catégories collectées / script : 'textToDBCrimeCategorie.php'
- création de la table 'crime'
- insertion des données dans la table 'crime' avec des requêtes pour les clés étrangères à partir des fichiers text 'data_ok_XXX.txt' / script : 'textToDBCrime.php'