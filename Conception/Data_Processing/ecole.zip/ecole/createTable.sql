CREATE TABLE `categorie_ecole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categorie` varchar(250) NOT NULL
)

ALTER TABLE `categorie_ecole`
  ADD PRIMARY KEY (`id`);


CREATE TABLE `ecole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_ecole` varchar(250) NOT NULL,
  `nom_commune_ecole` varchar(250) NOT NULL,
  `rue_addresse_ecole` varchar(250) NOT NULL,
  `code_postal_adresse_ecole` varchar(10) NOT NULL,
  `ville_adresse_ecole` varchar(250) NOT NULL,
  `numero_uai_ecole` varchar(250) NOT NULL,
  `id_position` int NOT NULL,
  `id_type` int NOT NULL,
  `id_commune` int NOT NULL
)

ALTER TABLE `ecole`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `ecole`
  ADD FOREIGN KEY (`id_position`) REFERENCES `position_gps`(`id`);
  
ALTER TABLE `ecole`
  ADD FOREIGN KEY (`id_type`) REFERENCES `categorie_ecole`(`id`);
  
ALTER TABLE `ecole`
  ADD FOREIGN KEY (`id_commune`) REFERENCES `commune`(`id`);
