## Process pour les données des communes / départements / régions

### sources
- communes, régions et départements : https://www.data.gouv.fr/fr/datasets/communes-de-france-base-des-codes-postaux/ 

### process
- création de la table 'region'
- peuplement de la table 'region', utilisation du script 'csvToDBRegion.php' qui lit le fichier csv 'regions-france.csv' ligne par ligne et fait les requêtes d'insert dans la table 'region'
- création de la table 'departement'
- peuplement de la table 'departement', utilisation du script 'csvToDBDepartement.php' qui lit le fichier csv 'departements-france.csv' ligne par ligne et fait les requêtes d'insert dans la table 'departement' avec requete préalable pour récupérer l'id de la région du département par son code.
- création de la table 'position_gps'
- création de la table 'commune'
- utilisation du script 'csvToTextCommune.php' qui extrait du fichier csv 'communes-departement-region.csv' les données nécessaires à la bd et les écrit dans le fichier text 'communes.txt'
- peuplement des tables 'commune' et 'position_gps', utilisation du script 'txtToDBCommune.php' qui lit le fichier 'communes.txt' et fait les requêtes d'insert dans les tables 'position_gps' puis 'commune' avec requetes préalables pour récupérer les id de la région et du département par leurs codes (et avec récupération de l'id de la position_gps insérée avant l'insert de la commune)
- génération des scripts sql de création et de peuplement des tables 'position_gps' et 'commune'