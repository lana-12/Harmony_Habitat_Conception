<?php

/**
 * Script qui fait des requêtes d'insertion sur la table 'crime' 
 * à partir d'un fichier text d'une année : 
 * 'data_ok_XXXX.txt'.
 * 2022 -> done
 * 2021 -> done
 * 2020 -> done
 * 2019 -> done
 */
try {
    $host = 'localhost';
    $dbName = 'harmony_habitat';
    $userName = 'user_harmony_habitat';
    $userPassword = 'harmony_habitat';

    $db = new PDO("mysql:host=$host;dbname=$dbName", $userName, $userPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $year = '2019';
    $sourceFile = "result/data_ok_$year.txt";
    if (($fileStream = fopen($sourceFile, 'r')) !== FALSE) {
        $count = 0;
        while (($line = fgets($fileStream)) !== FALSE) {
            $count++;
            echo 'ligne : ' . $count . PHP_EOL;
            $data = explode(';', $line);
            $code_commune = $data[0];
            $annee = $data[1];
            $categorie = $data[2];
            $crimeCount = intval($data[3]);
            $crimeRatio = $data[4];
            //echo 'code_commune : ' . $code_commune . PHP_EOL;
            //echo 'categorie : ' . $categorie . PHP_EOL;

            $communeQuery = $db->prepare('SELECT c.id_commune FROM harmony_habitat.commune c WHERE c.code_commune = ?');
            $communeQuery->bindValue(1, $code_commune, PDO::PARAM_STR);
            $communeQuery->execute();
            $communeRow = $communeQuery->fetch(PDO::FETCH_ASSOC);

            $crimeCategorieQuery = $db->prepare('SELECT c.id_categorie FROM harmony_habitat.crime_categorie c WHERE c.categorie = ?');
            $crimeCategorieQuery->bindValue(1, $categorie, PDO::PARAM_STR);
            $crimeCategorieQuery->execute();
            $crimeCategorieRow = $crimeCategorieQuery->fetch(PDO::FETCH_ASSOC);

            if ($communeRow && $crimeCategorieRow) {
                $id_commune = $communeRow['id_commune'];
                $id_categorie = $crimeCategorieRow['id_categorie'];
                $sql = 'INSERT INTO crime (annee_crime, nb_crime, taux_pour_mille, id_commune, id_categorie) VALUES (?, ?, ?, ?, ?)';
                $stmtCrime = $db->prepare($sql);
                $stmtCrime->bindValue(1, $annee);
                $stmtCrime->bindValue(2, $crimeCount, PDO::PARAM_INT);
                $stmtCrime->bindValue(3, $crimeRatio, PDO::PARAM_STR);
                $stmtCrime->bindValue(4, $id_commune, PDO::PARAM_INT);
                $stmtCrime->bindValue(5, $id_categorie, PDO::PARAM_INT);
                $stmtCrime->execute();
            }
            else {
                echo 'Erreur des sous-requêtes / ' . PHP_EOL;
                if(!$communeRow) echo 'commune ko / ' . PHP_EOL;
                if(!$crimeCategorieRow) echo 'categorie ko / ' . PHP_EOL;
            }
        }
        fclose($fileStream);
        echo 'Peuplement de la table \'crime\' pour l\'année ' . $year . ' terminé.' . PHP_EOL;
    }
} catch (PDOException $e) {
    echo 'Erreur : ' . $e->getMessage() . PHP_EOL;
}
