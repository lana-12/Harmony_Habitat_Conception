<?php

function dump($var)
{
    echo '<pre>';
    var_dump($var);
    echo '</pre>';
}

/**
 * Test sur ma BDD ecole avant
 * ok pour le peuplement de la BDD
 * RESTE A FAIRE
 *  - gestion des clés etrangères
 */
try {
    $host = 'localhost';
    $dbName = 'ecole';
    $userName = 'root';
    $userPassword = '';
    $db = new PDO("mysql:host=$host;dbname=$dbName", $userName, $userPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::MYSQL_ATTR_INIT_COMMAND, 'SET NAMES utf8');
    echo 'ok connexionnbhjvjvkghvhgikcv';

    $file = './txt/school2.txt';
    $count = 0;
    $typesSchool = [];

    // $data = [];
    if (($fileStream = fopen($file, 'r')) !== FALSE) {
        while (($line = fgetcsv($fileStream, 1000, ';')) !== FALSE) {
            $count++;

            // dump($line);

            // Gestion nomEcole vide
            if ($line[3] === "") {
                $line[3] = $line[2] . ' de ' . $line[6];
            }
            $code_commune_ecole = $line[0];
            $nom_commune_ecole = $line[1];
            $type_ecole = $line[2];
            $nom_ecole = $line[3];
            $adresse_ecole = $line[4];
            $code_postal_ecole = $line[5];
            $ville_ecole = $line[6];
            $latitude_ecole = $line[7];
            $longitude_ecole = $line[8];
            $numero_uai = $line[9];

            //Mise en Bdd type_ecole
            if (!in_array($type_ecole, $typesSchool)) {
                $typesSchool[] = $type_ecole;
                // Insérer le type d'école dans la table
                $insertTypeQuery = $db->prepare('INSERT IGNORE INTO type_school (name_type) VALUES (:name_type)');
                $insertTypeQuery->bindParam(':name_type', $type_ecole, PDO::PARAM_STR);
                $insertTypeQuery->execute();


                // Obtenez l'ID du type d'école inséré
                $typeIDQuery = $db->prepare('SELECT id_type FROM type_school WHERE name_type = :name_type');
                $typeIDQuery->bindParam(':name_type', $type_ecole, PDO::PARAM_STR);
                $typeIDQuery->execute();
                $typeId = $typeIDQuery->fetch(PDO::FETCH_COLUMN);
// var_dump($typeId);


                // Insérer dans la table ecole en utilisant l'ID du type d'école

                if($typeId ){
                    $type_ecole = $typeId;


                    $ecoleQuery = $db->prepare('INSERT INTO school 
                (name_school, address_school, zip_code_school, city_school, numero_uai, latitude_ecole, longitude_ecole, id_type, code_commune) VALUES 
                (:name_school, :address_school, :zip_code_school, :city_school, :numero_uai, :latitude_ecole, :longitude_ecole, :id_type, :code_commune_ecole )');


                    $ecoleQuery->bindParam(':name_school', $nom_ecole, PDO::PARAM_STR);
                    $ecoleQuery->bindParam(':address_school', $adresse_ecole, PDO::PARAM_STR);
                    $ecoleQuery->bindParam(':zip_code_school', $code_postal_ecole, PDO::PARAM_STR);
                    $ecoleQuery->bindParam(':city_school', $ville_ecole, PDO::PARAM_STR);
                    $ecoleQuery->bindParam(':numero_uai', $numero_uai, PDO::PARAM_STR);
                    $ecoleQuery->bindParam(':latitude_ecole', $latitude_ecole, PDO::PARAM_STR);
                    $ecoleQuery->bindParam(':longitude_ecole', $longitude_ecole, PDO::PARAM_STR);
                    $ecoleQuery->bindParam(':id_type', $typeId, PDO::PARAM_INT); // Utilisation de l'ID obtenu

                    $ecoleQuery->bindParam(':code_commune_ecole', $code_commune_ecole, PDO::PARAM_STR);
                    // $ecoleQuery->bindParam(':nom_commune_ecole', $nom_commune_ecole, PDO::PARAM_STR);
                    $ecoleQuery->execute();

                }
            }
            
            
            
        }
        fclose($fileStream);
        echo 'Insertion des données terminée.';
    } else {
        echo 'Erreur ouverture fichier CSV.' . PHP_EOL;
    }
} catch (PDOException $e) {
    echo 'Erreur : ' . $e->getMessage();
}
