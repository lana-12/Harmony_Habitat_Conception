<?php
/**
 * Script qui lit le fichier text des communes et peuple la table commune
 */
try {
    $host = 'localhost';
    $dbName = 'harmony_habitat';
    $userName = 'user_harmony_habitat';
    $userPassword = 'harmony_habitat';
    $db = new PDO("mysql:host=$host;dbname=$dbName", $userName, $userPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $csvFile = 'text/communes.txt';
    $count = 0;
    if (($fileStream = fopen($csvFile, 'r')) !== FALSE) {
        while (($data = fgetcsv($fileStream, 1000, ';')) !== FALSE) {
            $count++;
            echo 'ligne : ' . $count . PHP_EOL;
            $code_commune = $data[0];
            $code_region = $data[1];
            $code_departement = $data[2];
            if (strlen($code_departement) < 2) $code_departement = '0' . $code_departement;
            $nom_commune = $data[3];
            $code_postal = $data[4];
            if (strlen($code_postal) < 5) $code_postal = '0' . $code_postal;
            $latitude = round($data[5], 10);
            $longitude = round($data[6], 10);

            // gestion de la clé étrangère du département
            $departementQuery = $db->prepare('SELECT id_departement FROM departement WHERE code_departement = ?');
            $departementQuery->bindValue(1, $code_departement);
            $departementQuery->execute();
            $departementRow = $departementQuery->fetch(PDO::FETCH_ASSOC);

            // gestion de la clé étrangère de la région
            $regionQuery = $db->prepare('SELECT id_region FROM region WHERE code_region = ?');
            $regionQuery->bindValue(1, $code_region);
            $regionQuery->execute();
            $regionRow = $regionQuery->fetch(PDO::FETCH_ASSOC);

            if ($departementRow && $regionRow) {
                $id_departement = $departementRow['id_departement'];
                $id_region = $regionRow['id_region'];

                // insert de la position
                $stmtPosition = $db->prepare('INSERT INTO position_gps (latitude, longitude) VALUES (?, ?)');
                $stmtPosition->bindParam(1, $latitude);
                $stmtPosition->bindParam(2, $longitude);
                $stmtPosition->execute();
                // important !!
                $id_position = $db->lastInsertId();

                // insert de la commune
                $stmtCommune = $db->prepare('INSERT INTO commune (code_commune, code_postal, nom_commune, id_position, id_departement, id_region) VALUES (?, ?, ?, ?, ?, ?)');
                $stmtCommune->bindValue(1, $code_commune);
                $stmtCommune->bindValue(2, $code_postal);
                $stmtCommune->bindValue(3, $nom_commune);
                $stmtCommune->bindValue(4, $id_position, PDO::PARAM_INT);
                $stmtCommune->bindValue(5, $id_departement, PDO::PARAM_INT);
                $stmtCommune->bindValue(6, $id_region, PDO::PARAM_INT);
                $stmtCommune->execute();
            }
        }

        fclose($fileStream);
        echo 'Insertion des données terminée.';
    } else {
        echo 'Erreur ouverture fichier CSV.' . PHP_EOL;
    }
} catch (PDOException $e) {
    echo 'Erreur : ' . $e->getMessage();
}
