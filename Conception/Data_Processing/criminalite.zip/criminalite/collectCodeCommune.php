<?php
/**
 * Script qui collecte les codes commune sans doublons
 * à partir des fichier 'data_XXXX.txt'
 * et les enregistre dans le fichier 
 * 'codes_commune_sans_doublons.txt'
 */
$directory = './text/';
$codesCommune = [];
echo 'Collecte des codes de commune commencée' . PHP_EOL;
$fileCount = 0;
foreach (glob($directory . 'data_*.txt') as $file) {
    $fileCount++;
    echo 'fichier n° : ' . $fileCount . PHP_EOL;
    if (($fileStream = fopen($file, 'r')) !== FALSE) {
        $count = 0;
        while (($line = fgets($fileStream)) !== FALSE) {
            $count++;
            echo 'ligne n° : ' . $count . PHP_EOL;
            $data = explode(';', $line);
            $codeCommune = trim($data[0]);

            if (!in_array($codeCommune, $codesCommune)) {
                $codesCommune[] = $codeCommune;
            }
        }
        fclose($fileStream);
    }
}

sort($codesCommune, SORT_NUMERIC);
echo 'Ecriture des données' . PHP_EOL;

$outputFile = 'codes_commune_sans_doublons.txt';

if (($outputStream = fopen('text/' . $outputFile, 'w')) !== FALSE) {
    foreach ($codesCommune as $codeCommune) {
        fwrite($outputStream, "$codeCommune\n");
    }

    fclose($outputStream);
    echo 'Collecte des codes de commune terminée' . PHP_EOL;
} else {
    echo 'Erreur ouverture du fichier de sortie' . PHP_EOL;
}
?>
